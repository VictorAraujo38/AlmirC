﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    [Table("Atendimentos")]
    public class Atendimento
    {
        [Key]
        [Required]
        public int id { get; set; }
        [Required]
        public Aluno aluno { get; set; }
        [Required]
        public Sala sala { get; set; }
        [Required]
        public DateTime data { get; set; }
        [Required]
        public DateTime? hora { get; set; }
    }
}
