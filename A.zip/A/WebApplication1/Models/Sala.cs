﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    [Table("Salas")]
    public class Sala
    {
        [Key]
        [Required]
        public int id { get; set; }
        [Required]
        [StringLength(20)]
        public string descricao { get; set; }
        [Required]
        public int equipamentos { get; set; }
        [Required]
        public char situacao { get; set; }
    }
}