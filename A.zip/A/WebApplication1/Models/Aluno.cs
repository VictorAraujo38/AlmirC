﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    [Table ("Alunos")]
    public class Aluno
    {
        public enum PeriodoEnum
        {
            Manhã,
            Tarde,
            Noite
        }
        [Key] 
        public int id { get; set; }
        [Required]
        [StringLength(35)]
        public string nome { get; set; }
        [Required]
        public DateTime aniversario { get; set; }

        [Required]
        public Curso curso { get; set; }
        [Required]
        public  PeriodoEnum periodo{ get; set; }

    }
}
